//
//  globaldata.c
//  softsim
//
//  Created by András Libál on 7/20/18.
//  Copyright © 2018 András Libál. All rights reserved.
//

#include "globaldata.h"

struct global_struct global;
struct flag_struct flag;
